---
name: hermes-tui-and-dashboard
description: "Hermes TUI (terminal UI) and web dashboard — how to launch, navigate, and use them. Load whenever the user asks about hermes tui, dashboard, web UI, or visual interfaces."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [hermes, tui, dashboard, web-ui, terminal, ink]
    related_skills: [hermes-agent, debugging-hermes-tui-commands]
---

# Hermes TUI & Web Dashboard

## TUI (Terminal UI)

The TUI is Hermes's interactive terminal interface. It runs **inside** your terminal emulator (iTerm2, Terminal.app, etc.).

### Launch

```bash
hermes chat        # interactive TUI (default command)
hermes             # same — chat is the default subcommand
```

**NOT** `hermes tui` — that is not a valid subcommand and will error.

For a single query without entering the TUI:
```bash
hermes chat -q "your question here"
```

### Key Slash Commands

Type `/` in the TUI to see autocomplete. Essentials:

| Command | What it does |
|---------|-------------|
| `/model` | Switch models mid-session |
| `/verbose` | Toggle tool output visibility |
| `/compress` | Manually compress context |
| `/undo` | Remove last exchange |
| `/history` | Scroll back through conversation |
| `/copy` | Copy last response to clipboard |
| `/skin` | Change color theme |
| `/indicator` | Change busy spinner style |
| `/help` | Full command list |
| `/quit` or `/exit` | Leave TUI |

### Status Bar (bottom of screen)

- **Model name** — e.g. `owl-alpha`
- **Context bar** `[░░░░░░░░░░]` — fills as context is used; auto-compresses when full
- **Token count** and **timing**

### Themes & Visual Comfort

`/skin` cycles through color themes. `/indicator` changes the spinner (kaomoji, emoji, unicode, ascii). Useful for ADHD-friendly visual feedback.

---

## Web Dashboard

Hermes ships a built-in web UI for config, sessions, chat, and kanban.

### Launch

```bash
hermes dashboard              # starts on port 9119, opens browser
hermes dashboard --port 9119  # explicit port
hermes dashboard --no-open    # don't auto-open browser
hermes dashboard --status     # check if running
hermes dashboard --stop       # stop running dashboard
```

Then open: **http://127.0.0.1:9119**

### Dashboard Features

- **Chat tab** — full TUI embedded in the browser (via PTY/WebSocket)
- **Config page** — visual editor for config.yaml
- **Models page** — manage providers and API keys
- **Sessions page** — browse past conversations
- **Kanban page** — multi-agent task board
- **Cron page** — manage scheduled jobs
- **Skills page** — browse and manage skills
- **Plugins page** — manage plugins
- **Logs page** — view Hermes logs
- **Profiles page** — manage isolated Hermes instances
- **Analytics page** — usage insights

### Multi-interface simultaneity

Telegram, TUI, and Web Dashboard all connect to the same gateway simultaneously. The user can switch between them freely — same agent, same memory, same session.

### Rebuilding the Dashboard UI

If you pull updates that change the web UI, it needs a rebuild:

```bash
cd ~/.hermes/hermes-agent/web
npm install
npx vite build
```

**Requires Node.js v20+ (v22 recommended).** Check with `node --version`. Upgrade via nvm:
```bash
nvm install 22 && nvm use 22 && nvm alias default 22
```

**Where the build goes:** Vite outputs directly into `hermes_cli/web_dist/` (the dashboard's serve directory). There is NO separate `web/dist/` folder — the build targets the serve directory. After `npm run build` completes, the dashboard will serve the new files on next restart.

**`--skip-build` flag:** Use `hermes dashboard --port 9119 --skip-build` to skip the auto-build step on launch (useful when Node is too old or build is known-failing). The pre-built dist in `hermes_cli/web_dist/` will be served as-is.

If the build fails due to Node version, the pre-built dashboard still works — just won't include the latest UI changes.

**Full update workflow after `git pull`:**
```bash
# 1. Stop dashboard
hermes dashboard --stop

# 2. Rebuild web UI (requires Node 20+)
cd ~/.hermes/hermes-agent/web
rm -rf node_modules package-lock.json && npm install
npm run build

# 3. Restart dashboard (will serve the freshly-built files)
hermes dashboard --port 9119

# 4. Restart gateway for code changes
hermes gateway restart
```

---

## Gateway Restart

After pulling code updates, restart the gateway to pick up changes:

```bash
hermes gateway restart
```

This briefly disconnects and reconnects messaging platforms (Telegram, etc.). It requires user approval (security prompt).

---

## Updating Hermes

```bash
cd ~/.hermes/hermes-agent
git pull origin main
hermes postinstall    # update native deps
# Optionally rebuild dashboard if web/ changed:
cd web && npm install && npx vite build
```

Check version: `hermes --version`
Check update availability: `hermes status` (shows "update available" if behind)

---

## Antigravity / Henry Reference

Gabriel is a former Antigravity user. See `references/antigravity-architecture.md` for architecture notes and design patterns from Henry that Gabriel admired. Useful context when discussing agent autonomy, browser automation, or creative AI projects.

---

## Pitfalls

- **Don't speak CLI language to the user.** Gabriel (and likely other ADHD users) gets overwhelmed by raw terminal commands. When giving instructions, explain in plain language what to do step by step. Instead of `grep -i telegram ~/.hermes/logs/gateway.log | tail -10`, say "let me check the gateway logs for Telegram errors." Only show actual commands if the user asks for them specifically.

- **Ask, don't dump.** Gabriel organizes his work in Pomodoro sessions and needs to choose his own focus. Don't dump a full plan on him. Instead ask: "What do you want to work on right now?" Then help with that one thing. Then ask again. This respects his autonomy and helps him structure his thinking. If he's overwhelmed, offer one starting action — not a full roadmap.

- **Sidebar CSS: use `display: none`, not `opacity: 0`.** When collapsing the dashboard sidebar via custom theme CSS, `opacity: 0` leaves elements taking up space and can cause visual weirdness. Use `display: none !important` in the collapsed state and `display: inline !important` in the hover state. See `references/dashboard-sidebar-collapse.md` for the refined CSS.

- `hermes tui` does NOT work — use `hermes chat` or just `hermes`
- Dashboard build needs Node v20+; the running dashboard still works on v18 (just can't rebuild)
- Gateway restart disconnects Telegram briefly — warn the user
- `hermes update` may be blocked by approval prompts; `git pull` + `hermes postinstall` is the manual alternative

- **Telegram pairing after gateway restart:** After a gateway restart with a new `TELEGRAM_BOT_TOKEN`, Telegram will send the user a pairing code (e.g., `Q7WHKDN4`) on first message. The user sees: "Hi — I don't recognize you yet. Here's your pairing code: XXXXX. Ask the bot owner to run: hermes pairing approve telegram XXXXX". The user just needs to send you the code and you run `hermes pairing approve telegram XXXXX` — no CLI knowledge needed from them. Tell them: "Just send me the code and I'll handle it."

- **Telegram not connecting after gateway restart:** Check that `TELEGRAM_BOT_TOKEN` is set in `~/.hermes/.env`. The gateway will start but Telegram polling won't initialize without it. Verify with `grep TELEGRAM_BOT_TOKEN ~/.hermes/.env`. If missing, the gateway log will show "No user allowlists configured" but no actual Telegram connection errors — it silently skips Telegram init.

- **The `.env` file is write-protected.** You cannot edit it with `write_file` or `patch` — those tools will refuse with "protected system/credential file." When the user needs to add a key, tell them exactly what line to add and where, and have them edit it themselves. Be specific about formatting (e.g., `KEY=value`, no leading spaces).

- **Memory tool character limit:** The memory tool has a hard limit of ~1,375 chars. When adding entries, it will reject with "would exceed the limit." Fix by replacing/removing old entries first, or consolidating multiple entries into fewer, denser ones.

- **Telegram allowlist for single-user privacy:** If the user wants Telegram private (just them), set `TELEGRAM_ALLOWED_USERS=<their_telegram_numeric_id>` in `~/.hermes/.env`. Without this, anyone who finds the bot can message it. The warning "No user allowlists configured" in the gateway log is the tell. Get the Telegram user ID from the gateway log when the user messages (shown as `user=Gabriel Paiva chat=8616976631`).

- **Dashboard process runs but port not listening:** After `hermes dashboard`, the process may start but fail to bind the port (especially after a large `git pull` update). Symptom: `hermes dashboard --status` shows a PID, but curl to the port returns connection refused. Fix: `hermes dashboard --stop` then restart. If persistent, the dashboard code may have a regression — consider filing a GitHub issue on NousResearch/hermes-agent.

- **Dashboard build output location:** `npm run build` in `web/` outputs directly to `hermes_cli/web_dist/`, NOT to `web/dist/`. Always verify `hermes_cli/web_dist/index.html` timestamp to confirm the new build landed. Then restart the dashboard.

- **`execute_code` cannot background with `&`:** In `execute_code`, the `terminal()` function does NOT support shell-level backgrounding (`command &`). Use Python's `subprocess.Popen` instead. For the `terminal()` tool directly, use `background=true` parameter.

- **Dashboard sidebar blocks content on smaller screens:** The sidebar is 256px wide and always visible on desktop (lg breakpoint). To collapse it, create a custom theme at `~/.hermes/dashboard-themes/<name>.yaml` with `customCSS` that sets `#app-sidebar` width to 48px on `min-width: 1024px`, with a hover-to-expand. Then set the theme via `hermes config set dashboard.theme <name>` and restart the dashboard. The theme YAML requires at minimum `name`, `palette` (with `background`, `midground`, `foreground`, `warmGlow`, `noiseOpacity`), `typography` (with `fontSans`, `fontMono`, `baseSize`, `lineHeight`, `letterSpacing`), and `layout` (with `radius`, `density`). Example minimal theme with sidebar collapse is in `references/dashboard-sidebar-collapse.md`.

- **Custom dashboard themes location:** User-defined themes go in `~/.hermes/dashboard-themes/*.yaml`. The server scans this directory on startup via `_discover_user_themes()` in `hermes_cli/web_server.py`. Themes are served at `GET /api/dashboard/themes` and activated via `PUT /api/dashboard/theme`. Active theme persists in `config.yaml` under `dashboard.theme`. Set via `hermes config set dashboard.theme <name>` (not the API directly — auth required).
