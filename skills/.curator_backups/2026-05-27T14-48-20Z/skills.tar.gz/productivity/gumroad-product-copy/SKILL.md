---
name: gumroad-product-copy
description: "Write and publish Gumroad product listings — clean, direct, honest copy for digital products (prompt packs, templates, guides). Load when creating or reviewing Gumroad product descriptions, titles, tags, or pricing strategy."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos, linux, windows]
metadata:
  hermes:
    tags: [gumroad, ecommerce, copywriting, product-listing, digital-products, marketing]
    category: productivity
---

# Gumroad Product Copy

Write product listings that sell on substance, not hype. For digital products — prompt packs, templates, guides, cheat sheets, digital assets.

## When to use this skill

- Writing or reviewing Gumroad product titles, descriptions, or tags
- Pricing digital products for launch or emergency sales
- Preparing product copy for any marketplace (Gumroad, Lemon Squeezy, etc.)
- Reviewing existing listings for tone/voice problems

## Core principle: substance over hype

Gabriel's audience is creators, marketers, freelancers, and technical people. They can smell fake from a mile away. The copy should sound like a competent human explaining what they made — not a sales funnel.

### What to NEVER do

- **No emojis in headings or bullet points.** (A few in social posts is fine, but never in the product listing itself.)
- **No "✨ INTRODUCING ✨" energy.** No caps-lock excitement. No "game-changing" or "revolutionary."
- **No fake social proof.** No "Alex: 'This changed my life!'" with no last name, no context, no verifiable detail.
- **No inflated claims.** "The ultimate, battle-tested, most complete collection ever assembled" — nobody believes this.
- **No ClickFunnel formatting.** No bold-emoji-bullet lists. No "Here's what you're getting:" followed by ✅ checkmarks.
- **No urgency/scarcity lies.** "Only 3 left!" when it's a digital product with unlimited copies.

### What TO do

- **Lead with what's inside.** Specific numbers, specific categories, specific use cases.
- **Be precise about the format.** "CSV file with 231 prompts" — not "instant digital download."
- **Use plain language.** Short sentences. Active voice. "Paste into ChatGPT and get results" — not "Leverage the power of AI-driven prompt engineering."
- **Include the honest math.** If it's 231 prompts across 7 categories, say that. Specificity builds trust.
- **Price fairly and say why.** If it's $9 because of an emergency launch, you can say that. Gabriel's audience respects honesty.
- **Tags matter.** Use all available tag slots. Think about what the buyer would search for.

## Listing structure

### Title format
`[Product Name] — [Number] [Type] for [Specific Use Case]`

Examples:
- `SEO Domination Kit — 231 AI Prompts for Keyword Research, Content Optimization & Ranking`
- `Email & Newsletter Mastery — 204 Prompts for Outreach, Sequences & Conversions`

### Description structure
1. **One-line summary.** What is this, in one sentence.
2. **What's inside.** Bullet list of categories/coverages. Be specific.
3. **How it works.** "Paste into any AI tool. Get actionable output."
4. **What you get.** File format, number of items.
5. (Optional) Brief context on who made it and why — only if authentic.

### Tags
Use all available tag slots. Mix broad (ai prompts, marketing) with specific (keyword research, email sequences).

## Pricing strategy — Gabriel's approach

### Core philosophy: honest value, never cheap

Gabriel does NOT sell cheap. His products are precision-built (physicist + photographer — he thinks in systems) and priced accordingly. Cheap prices send a signal that undermines his credibility and his work.

**Key principle:** If the price feels low, make sure people understand WHY. Transparency about circumstances (medical costs, family situation) turns a discount from "this must be low quality" into "this is a genuine deal from someone who builds quality things."

### Pricing tiers for the prompt library

| Tier | Prompts | Honest price |
|------|---------|-------------|
| Single-niche pack (e.g., Social Media, E-commerce) | 68–81 | **$14** |
| Standard pack (e.g., SEO, Email, YouTube) | 110–231 | **$19** |
| Bundle (Content Empire = 3 modules) | 269 | **$29** |
| **Full Arsenal (all 1,056)** | **1,056** | **$49** |

### Math for the $200 target

- Full Arsenal at **$49** → **5 sales = $245** ($200 for meds + $45 for next week)
- Mix (2 Arsenal + 4 individual packs) ~ $160 + need 2 more

### The "why" in the pitch

The price needs explanation when it's below normal market rate. Be honest, but keep it focused on the product, not personal hardship.

**OK:** "Life happens. I'm making these available at this price because I need to get them into the hands of people who'll use them."

**TOO HEAVY for product pitches:** "$200/week in meds for my son" / "it is killing me that I am failing" — this makes the buyer carry your pain. People buy solutions, not guilt.

**The balance:** "Life happens" acknowledges reality without dumping the load on the buyer. Save the deeper story for direct conversations, not broadcast messages.

### Bundle math
Always show the comparison. "This is what it usually looks like and costs [$X]. I'm selling it for $Y." People need to see the value gap.

### When NOT to discount

- Don't drop prices below what the product is worth just to move units faster. Cheap prices erode trust.
- Don't use fake urgency ("only 3 left"). Real urgency (medical deadline) is fine — just be honest about it.
- Don't set prices so low that the buyer questions quality. The product has 1,056 tested prompts — that's worth $49 minimum.

## Voice calibration

Gabriel's voice: direct, precise, confident without arrogance. He's a photographer and physicist — he thinks in systems and specifics. The copy should sound like him explaining the product to a colleague over coffee.

**Before (wrong — Toddler Kit style):**
> ✨ INTRODUCING: THE ULTIMATE SEO BUNDLE ✨
> Stop struggling with SEO forever! This game-changing collection of 231 battle-tested prompts will REVOLUTIONIZE your workflow!
> ✅ Keyword Research
> ✅ Competitor Analysis
> ✅ Link Building
> Get the complete system that SEO pros don't want you to know about!

**After (right — Gabriel's style):**
> 231 AI prompts covering the entire SEO workflow: keyword research, competitor analysis, on-page optimization, link building, technical audits, local SEO, and SERP tracking.
>
> No "what is SEO" filler. Every prompt is structured — paste it into ChatGPT, Claude, or any LLM and get actionable output immediately.
>
> What you get: CSV file with 231 prompts, tagged by category.

## Post-launch: driving traffic

Products being live on Gumroad does NOT generate sales or even visits. This is the single most important lesson from Gabriel's launches. **Traffic is the bottleneck, not product quality.**

### The distribution reality

Gumroad is a payment processor + file delivery system, NOT a marketplace. It has no built-in discovery. A product with 0 visits has 0% chance of selling. The launch is not complete when the product is published — it's complete when the first sale arrives.

For emergency targets (like Gabriel's $200 for Julien's meds), the math is:

| Path | Sales needed |
|------|-------------|
| Full Arsenal at $49 | 5 sales = $245 |
| Mix (2 Arsenal + 4 individual) | ~$160, needs 2 more |
| Individual packs at $19 avg | ~11 sales |

### Outreach channels (priority order for Gabriel)

1. **LinkedIn InMail (highest ROI)** — 126 connections, 29K impressions/2 weeks, Premium account with InMail credits. Targeted 1:1 messages to marketing managers, content creators, SEO specialists, and freelancers in his network. See `references/outreach-templates.md` for InMail templates with warm vs. cold variants and targeting strategy.

2. **Direct messages** — Telegram, Discord communities the seller already participates in (Gabriel's Venice.ai Discord gave him his only previous downloads).

3. **LinkedIn posts** — Feed posts to the existing 126 connections. 3 variants available (story-driven, credibility-driven, short/punchy).

4. **Abacus.ai DeepAgent or other outreach agents** — Gabriel has agents set up (Abacus DeepAgent, Accomplish, Antigravity, Codex) that can automate outreach at scale.

### DeepAgent setup (as of May 2026)
Abacus changed DeepAgent — it now requires BOTH "instructions" and "skills" fields. 
- **Workflow** = API calls only, NO browser automation (cannot log into LinkedIn or send InMails).
- **Scheduled Task (Daemon)** = opens a real browser, logs in as user, clicks and types. THIS is what's needed for LinkedIn InMail automation.

When configuring DeepAgent for LinkedIn outreach:
1. Choose "Scheduled Task" not "Workflow"
2. Instructions field: use the goal/purpose, inputs, outputs, trigger, and external services format (see session for exact Q&A format)
3. Skills field: requires browser automation capability
4. The daemon can: open LinkedIn, navigate connections, read profiles, personalize first sentence, select relevant products, send InMails using Premium credits

5. **Community posting** — Relevant Discord servers, Reddit communities, niche forums where the target audience hangs out.

### Outreach targeting (LinkedIn specific)

- Priority 1: Existing network connections with marketing/content/SEO roles
- Priority 2: 2nd-degree connections found via LinkedIn search filters
- Priority 3: People who engaged with previous posts (the 29K impressions audience)

Target 10–15 InMails per day. Realistic conversion: 1–2 sales per batch. Continue daily for a week to hit $200.

### The post-launch checklist

When a product has been live for 24+ hours with no sales:
1. Verify the listing is actually published and visible (visit the URL in incognito)
2. Check if the price is set (not $0 or hidden)
3. Verify the product description is complete (empty descriptions kill conversions)
4. Check Gumroad Dashboard → Sales tab for actual data (not the storefront)
5. **Run the full store infrastructure audit** (checkout settings, emails, workflows, affiliates — see `references/gumroad-audit-checklist.md` Step 7). Products being published is step 1; the sales engine (emails, workflows, checkout optimization) is step 2. Both must be complete before outreach begins.
6. Start active outreach — the product is waiting, but nobody knows it exists

## Product audit / QA (reviewing existing listings)

When a user asks for a "Gumroad audit" or you're troubleshooting why published products aren't selling, run through this checklist systematically — one product at a time, explaining findings as you go.

### Audit workflow

1. **Visit each product's PUBLIC page** (not the editor). Log out or use incognito view. What the buyer sees is what matters.
2. **Screenshot or snapshot the page.** Check each section listed below.
3. **Document findings per product.** Present them clearly before moving to fixes.
4. **Fix issues one at a time** — go back to the editor, make the change, re-check the public page.
5. **Ask for confirmation** before moving to the next product or category of fix.

### What to check per product

| Element | What to look for |
|---------|-----------------|
| **Title** | Complete? Matches the product's actual content? Not truncated? |
| **Price** | Correct? Showing same as dashboard? Not $0 when it should be paid? |
| **Cover image** | Present? Decent quality? Not a generic placeholder? |
| **Description formatting** | Is it rich text (headings, paragraphs, bullets) or trapped in a `<code>` block? Code blocks look like terminal output — terrible for conversions. |
| **Description content** | Specific numbers, categories, file format? No hype/filler? |
| **File attachments** | Are the deliverable files actually attached? Buyer can't download an empty listing. |
| **Tags** | All available slots filled? Relevant search terms? |

### The code-block description pitfall ⚠️

**Problem:** When pasting description content into Gumroad's editor, if the text enters as a code block (the language selector shows something like "Arduino" or "Markdown"), it renders as a gray `<code>` box with a "Copy" button on the public page. The description looks like terminal output, not a product page. This is the #1 thing that makes a listing look unfinished.

**Detection:** Visit the public product page. If the description appears inside a gray box with a "Copy" button in the corner, it's a code block. It should look like normal rich text (headings, paragraphs, bullet lists).

**Fix (manual):** Edit the product in Gumroad, delete the code-block content, and paste the description as **plain text** — then reformat with proper headings and bullets using the toolbar. Do NOT paste formatted text from a markdown or HTML source.

**Fix (browser automation — faster for multiple products):** When editing via browser automation, Gumroad's rich text editor uses **ProseMirror** which won't detect `innerHTML` changes unless input/change events are dispatched.

  1. Navigate to the product's edit URL: `https://gumroad.com/products/<id>/edit`
  2. Focus the ProseMirror editor: `document.querySelector('.ProseMirror').focus()`
  3. Select all content: `document.getSelection().selectAllChildren(pmElement)`
  4. Delete with `Backspace` (via `browser_press`)
  5. Set clean HTML and dispatch events:
     ```js
     const pm = document.querySelector('.ProseMirror');
     pm.innerHTML = `<h2>Heading</h2><ul><li>Item</li></ul><p>Text</p>`;
     pm.dispatchEvent(new Event('input', { bubbles: true }));
     pm.dispatchEvent(new Event('change', { bubbles: true }));
     ```
  6. Click "Save changes"
  7. **Verify on the public page** — navigate to the public URL (not the editor) to confirm the code block is gone. Sometimes the save doesn't sync immediately; check visually with `browser_vision`.
  
  **Important:** Save may silently fail if ProseMirror didn't register the change. Always re-load the editor page and verify the content is still clean before navigating away. If the first save didn't stick, edit again with `browser_navigate` to the edit URL directly — the innerHTML+dispatch technique works reliably on the second attempt.

**Cause:** This happens when the description was originally pasted as markdown or code-formatted text during product creation. Gumroad's rich text editor (ProseMirror) honors markdown code-fence syntax and wraps it in `<code>` tags. The editor displays a language dropdown (showing "Arduino" or "Markdown") and wraps the content in a `<pre><code>` block.

### Presentation matters for conversion

A clean, readable product page is table stakes. If the description looks like a paste job, the buyer assumes the product itself is a paste job. This is especially important for digital products where trust in the creator is the main purchase driver.

## Pacing with Gabriel (always)

Gabriel moves at his own pace. Pushing faster costs trust, not time.

- **"Don't go YOLO"** — don't jump ahead to the next task without confirming the current one is understood and complete.
- **Step by step, with explanation.** He needs to understand what you're doing and why. Don't batch 5 actions and do them silently. Do one, explain it, wait for confirmation.
- **"I am slow by nature"** — respect this. His pace produces quality work. Rushing creates mistakes and frustration.
- **If he says "slow down," "calm down," "relax," or "wait"** — STOP immediately. Don't repeat the question. Don't barrel ahead. Let him set the pace.
- **Don't repeat the same ask multiple times.** If he hasn't responded, don't re-ask 5 times in different ways. Ask once, offer a clear alternative if needed, and wait.
- **Don't barrel ahead autonomously** while he's engaged on something else. Wait for confirmation before proceeding.
- **Honesty is paramount.** If you think he's wrong about something, say so directly and clearly. He values candor over agreement.
- **If the user says they're stepping away** (shower, kids, errands), DO NOT start new tasks without their explicit instruction. Finish what's in progress, save state, and wait. Starting work while they're away erodes trust — they come back to changes they didn't authorize and have to catch up.

### Login and session management

- **Login is ALWAYS the first step.** Nothing happens without it. Get credentials or have the user log in before doing ANY file work, product research, or planning. Login is the bottleneck — resolve it first.
- **Gumroad uses email-based 2FA.** After entering email+password, Gumroad sends an authentication code to the email. You MUST have the user check their email and provide the code in real-time (codes expire quickly — enter immediately). Google/X/Stripe OAuth options also require manual user interaction — email+password is the most automatable path.
- **Browser sessions expire during long tasks.** If the browser is idle or navigating between pages, the session can drop, requiring re-login + 2FA. Batch operations to minimize navigation. Have the user stay available for 2FA codes throughout.
- **File picker dialogs block the entire browser.** Native `<input type="file">` dialogs freeze the browser session until the user manually closes them. NEVER click a file upload button unless you're ready to handle the dialog. **Workaround:** Set up all product details first, then have the user upload files manually as a final step.

### Product creation

- **Don't assume the delivery format.** Always confirm with the user what the product deliverable looks like before preparing files. "Raw CSV" is almost never the right answer — buyers want something presentable. Default expectation: ZIP bundle with CSV + PDF + HTML webapp.
- **Gumroad product creation via browser:** The flow is: Name → Price → "Next: Customize" → "Save and continue" → Content tab → upload files + description → Publish. The "Save and continue" button (not "Next") advances past the initial setup. Use `browser_console` with JS to click buttons when refs go stale.
- **Product packaging (standard bundle):** Every product should deliver a ZIP file containing: CSV (raw data) + PDF (formatted, with cover and TOC) + HTML webapp (single self-contained file, works offline, with category filtering and copy-to-clipboard). Raw CSVs alone are not acceptable — Gabriel's audience expects presentable deliverables.

### Copy delivery format for Gabriel

When writing product copy that Gabriel will **manually paste** into Gumroad (or any other editor), follow this rule:

- **Provide clean, unformatted plain text** — NOT markdown, NOT code blocks, NOT HTML. Just text with line breaks between sections.
- OR **ask him if he wants you to format it** — he may prefer to do it himself since Gumroad's editor is "painful to use."
- NEVER give him formatted markdown (code blocks, fences, backtick-wrapped text). When pasted into Gumroad's ProseMirror editor, markdown code blocks render as a `<code>` box with a "Copy" button — looks broken to buyers.
- The correct delivery: write the description in plain paragraphs, then say "Here's the copy — let me know if you want me to format it in the editor directly instead."

This applies to all copy that Gabriel will handle manually. If you (the agent) are doing the editing via browser automation, use the techniques in the `gumroad-storefront` skill instead.

### Copy and content

- **Don't write copy you wouldn't believe.** If it sounds like a late-night infomercial, delete it.
- **Don't pad the description.** If you said what it is in 5 lines, stop. Nobody reads 500 words of product description on Gumroad.
- **Don't forget the file format.** Buyers want to know: CSV? PDF? ZIP? How many files?
- **Don't use Gumroad's "pay what you want" unless there's a reason.** Fixed prices convert better for digital products under $50.
- **Gumroad doesn't attract traffic.** The listing is necessary but not sufficient. Distribution (outreach, social posts, community sharing) is what actually sells. See the outreach templates in references/.
- **Leverage existing reviews.** If the seller's account has reviews on other products (even free ones), reference them. "5-star reviews on my free toolkit" builds trust for paid listings. Buyers check seller profiles.
- **Use free products as lead magnets.** A free product (like Gabriel's Toddler Kit) at $0+ builds social proof and gets people into the ecosystem. Link from the free product's description to paid products. The free product IS the top of the funnel.

## References

- `references/gumroad-listing-examples.md` — Real examples of Gabriel's 7 product listings at emergency pricing
- `references/outreach-templates.md` — LinkedIn, DM, and social outreach templates for product launches
- `references/linkedin-inmail-template.md` — Final InMail template with ALL 7 products listed (no tailored links), "life happens" tone
- `references/emergency-launch-playbook.md` — Emergency launch strategy, product table, revenue math, key lessons, and session status
- `references/deepagent-prompt-patterns.md` — 6 proven Abacus DeepAgent prompt patterns for outreach, research, content pipelines, and automation (browser-use, CSV workflows, X/Twitter growth, LinkedIn ops, analytics pulls, multi-node pipelines)
- `references/gumroad-publishing-guide.md` — Browser workflow for creating/publishing Gumroad listings, file picker pitfalls, 2FA handling, and session management
- `references/gumroad-audit-checklist.md` — Full store audit checklist covering: product pages, payment/payouts, **store infrastructure (checkout settings, emails, workflows, affiliates, sales, analytics)**, and traffic/distribution. Step-by-step with known issues from Gabriel's store. Use for zero-sales triage — products being published does not mean the store engine is ready.

## Publishing workflow (browser)

The skill description says "write and publish." Publishing is a browser task — Gumroad has no API for product creation.

### Prerequisites — resolve in this order
1. **Gumroad login FIRST.** Nothing happens without it. Get credentials or have the user log in before doing any file work.
2. **Confirm delivery format with the user.** Don't assume raw CSVs. Gabriel's standard is a ZIP bundle: CSV + PDF + offline HTML webapp.
3. Prepare all files (see "Product packaging" below) before opening the browser.

See `scripts/generate-products.py` for the generator. Run:
  python3 scripts/generate-products.py <csv> <out.html> <out.pdf> "<title>" "<subtitle>"

### Product packaging (standard bundle)

Every product should deliver a ZIP file containing:
- **CSV** — raw data, importable
- **PDF** — formatted, readable, with cover page and table of contents
- **HTML webapp** — single self-contained file, works offline, with category filtering and copy-to-clipboard

See `templates/prompt-webapp.html` for the HTML template. See `scripts/generate-pdf.py` for PDF generation.

### Product creation flow
1. Navigate to `https://gumroad.com/products/new`
2. Fill in: **Name** (the Gumroad title from the listing file)
3. Fill in: **Price** (numeric, in USD)
4. Upload the ZIP bundle (contains CSV + PDF + HTML)
5. Paste the description into the rich text editor
6. Add tags (all available slots)
7. Click **Publish**
8. Repeat for each product

### Notes
- Gumroad's editor is a rich text area — plain text pastes cleanly, but formatting (bullets, bold) may need re-application
- File upload accepts CSV, PDF, ZIP directly — upload the ZIP bundle
- Price field: enter just the number (e.g. `9`), Gumroad adds the `$`
- Each listing takes ~2–3 minutes once logged in
- **Don't prepare files before confirming login works.** Login is the bottleneck — resolve it first.
