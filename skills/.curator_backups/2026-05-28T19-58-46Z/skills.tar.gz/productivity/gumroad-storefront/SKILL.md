---
title: Gumroad Storefront Management
name: gumroad-storefront
description: Manage Gumroad product pages — audit descriptions, fix formatting (code blocks), update via browser automation. Companion to gumroad-product-copy (copy writing).
---

# Gumroad Storefront Management

Managing product pages on the Gumroad storefront, including auditing descriptions, fixing formatting issues, and editing via the browser-based WYSIWYG editor.

## Prerequisites
- Log in to Gumroad at `app.gumroad.com` (or gpframes.gumroad.com for Gabriel's store)
- Credentials: stored in memory

## Audit Workflow

Check every product page on the **public storefront** (`gpframes.gumroad.com`):

1. Navigate to each product's public URL (e.g., `gpframes.gumroad.com/l/full_arsenal`)
2. Check if the description renders in a `<code>` block (gray box with "Copy" button)
   - This happens when markdown was pasted directly into the Gumroad WYSIWYG editor
   - Products **should** show clean: H2 headings, `<p>` paragraphs, `<ul>` lists
3. Also check: cover image present, price correct, title clean

## Fixing Code Block Descriptions

### Navigate to the editor

**Method 1 (from products list):** Go to `gumroad.com/products`, wait for table to load (`document.querySelectorAll('tr').length > 0`), then find the product's internal edit URL:
```javascript
const allLinks = document.querySelectorAll('a[href*="/edit"]');
for (const link of allLinks) {
  if (link.textContent.includes('[product name]')) {
    link.click();
    break;
  }
}
```
Then verify `window.location.href` changed to `/products/<id>/edit`.

**Method 2 (direct URL, most reliable):** Get the product's internal ID from the products page (`/products/<id>/edit`), then navigate directly via `browser_navigate`. This avoids React SPA routing issues entirely.

**Method 3 (from public page):** Navigate to the product's public URL (e.g., `gpframes.gumroad.com/l/youtube_growth`), then use JS to click the "Edit product" link:
```javascript
const editLink = document.querySelector('a[href*="edit"]');
if (editLink) editLink.click();
```

### Clear and update description

1. Focus the ProseMirror editor and select all content (two approaches — use whichever works):
```javascript
// Approach A — selectAllChildren
const p = document.querySelector('.ProseMirror');
p.focus();
document.getSelection().selectAllChildren(p);

// Approach B — createRange (use if approach A fails)
const p = document.querySelector('.ProseMirror');
p.focus();
const sel = window.getSelection();
const r = document.createRange();
r.selectNodeContents(p);
sel.removeAllRanges();
sel.addRange(r);
```
2. Press `Backspace` to delete selected content. Verify empty:
```javascript
document.querySelector('.ProseMirror').textContent.trim() === ''
```
3. Inject clean HTML:
```javascript
p.innerHTML = `<h2>Clean heading here</h2>
<p>Paragraph text.</p>
<ul>
  <li>Bullet item</li>
</ul>`;
p.dispatchEvent(new Event('input', { bubbles: true }));
p.dispatchEvent(new Event('change', { bubbles: true }));
```
4. Click "Save changes" button (usually `@e20` in the snapshot)

### Important: browser_console variable scoping

The `browser_console` tool shares a single JavaScript scope across ALL calls in a page session. This means:

```javascript
// Call 1 — works
const pm = document.querySelector('.ProseMirror');
'PM found: ' + !!pm

// Call 2 — FAILS with SyntaxError
const pm = document.querySelector('.ProseMirror');
pm.focus();
// → "SyntaxError: Identifier 'pm' has already been declared"
```

**Fix:** Use unique variable names each time (`pm`, `pmEditor`, `pme`, `ed`, `editorEl`, `pm2`, `proseMirror`). Don't reuse `pm` or any other `const` name across separate `browser_console` calls. Alternatively, omit `const`/`let` on subsequent uses and just reassign.

This also affects `document.querySelectorAll` variables and any other `const`/`let` declarations. Always use fresh names.

### Verify save persisted (critical)

Gumroad saves don't always persist on first attempt — especially with `innerHTML` injection since ProseMirror may not register it as an edit. **Always verify on the public page**:

1. Navigate to `gpframes.gumroad.com/l/<product_slug>` (not the editor)
2. Check the description shows clean H2/paragraphs/lists, not a `<code>` block
3. If old content is still showing, return to editor, re-clear, re-inject events, and save again. The second save usually works.
4. The public page may serve a cached version — navigate away and back if update doesn't appear immediately

### When to use `selectAllChildren` vs `createRange`

Sometimes `document.getSelection().selectAllChildren(pm)` doesn't select the full content (especially when code-block elements are nested). Fall back to:

```javascript
const sel = window.getSelection();
const r = document.createRange();
r.selectNodeContents(pm);
sel.removeAllRanges();
sel.addRange(r);
```

Try `selectAllChildren` first. If the selection looks incomplete (partial content), use `createRange`.

### Important: content format

When writing copy for the user to paste, provide **clean formatted text** (plain text with line breaks), NOT markdown code blocks. Markdown blocks pasted into Gumroad's WYSIWYG editor render as ugly `<code>` blocks with a "Copy" button — looks broken to buyers.

## Curating the Storefront: Hiding Products (Storefront Purification)

When the user wants to show only a specific subset of products on their public profile/storefront (e.g. focusing the brand on a specific premium set and hiding legacy, free, or draft items):
1. **Unpublish Distractors:** Do NOT delete products. Instead, unpublish them. Unpublishing hides them from the public storefront page (`gpframes.gumroad.com`) but retains them on the account as drafts. Existing links and old buyers are completely unaffected.
2. **Programmatic Unpublish Workflow:**
   - Go to the edit page: `https://gumroad.com/products/[id]/edit`
   - Locate and click the "Unpublish" button:
     ```javascript
     const btn = Array.from(document.querySelectorAll('button')).find(b => b.innerText.trim() === 'Unpublish');
     if (btn) btn.click();
     ```
   - Wait 4 seconds for saving to complete.
3. **Verification:** Navigate back to `https://gumroad.com/products` and verify that the product's Status column has toggled to `Unpublished`.

## Pitfalls

- **Respect the User's Live Production Setup (CRITICAL RULE):** Never edit the user's live storefront, bio, colors, or redirect settings without their **explicit, direct permission**. A user's storefront layout and biography are active business assets. "Proactive improvements" or unauthorized edits on live production settings will trigger extreme frustration, a complete loss of trust, and break their operational brand strategy. Always ask before changing live profiles.
- **Dynamic ID Selectors in Settings/Profile Forms:** Modern Gumroad settings and profile forms employ dynamic rendering libraries (like React's `useId()`) which generate different hashes for input/textarea IDs on each load (e.g., `:r1:-bio` vs `:r2:-bio`). Do NOT target static compiled hashes. Instead, select elements generically using tag names and attributes (e.g., `textarea` or `textarea[id$="-bio"]`) combined with async waiting/polling (polling for up to 15 seconds) to handle slower React mounts.
- **Auto-Save & Form Submission in Profile Editor:** Some settings pages save inputs asynchronously via background fetch, while others require clicking "Update settings" or "Save." Always run a JS script that dispatches both `input` and `change` events with `bubbles: true` after editing the field value, then locate and click the submit button (e.g., `button[type="submit"]` or a button containing text "Update" or "Save"). Always wait 8 seconds and check the public storefront page (`https://gpframes.gumroad.com/`) to verify that the change successfully committed and cleared the CDN cache.
- **Chrome Debug Lock (macOS):** When running headless browser automations, a running standard Chrome instance can cause ProcessSingleton locking conflicts. Bypassing this safely requires: (a) copying the `/Cookies` SQLite file to `/tmp/chrome_profile2/Default/Cookies`, (b) quitting standard Chrome via `osascript`, (c) executing the headless instance on the temporary profile, and (d) restarting standard Chrome on finish.
- **Browser-Side Filtering in JS Eval:** Do NOT return massive unfiltered DOM dumps from `browser_console` or browser evals, as this triggers size overflows and truncations. Always filter, lowercase (using JavaScript's `.toLowerCase()`, not Python's `.lower()`), and serialize elements directly in the browser context before returning them.
- Gumroad uses a React SPA — clicking <a> links via browser_click may not navigate. Use JavaScript .click() instead.
- The ProseMirror editor may not detect `innerHTML` changes unless you dispatch `input` and `change` events.
- **Browser console variable redeclaration:** `browser_console` expressions that redeclare a variable name (e.g., `const pm = ...` in one call, then `const pm = ...` in the next) throw `SyntaxError: Identifier 'X' has already been declared`. The browser console shares a single scope across all calls — it does NOT create a new scope per invocation. Use unique variable names each time (`pmEditor`, `pme`, `editorEl`, `pm2`) or omit `const`/`let` on subsequent uses of the same variable. This is especially painful when repeatedly editing multiple product pages in sequence.
- After navigating away and back to the products page, the table may not re-render immediately. Wait or use `browser_navigate` to force a fresh load.
- The products table rows may not be queryable via `textContent` matching — the React rendering nests elements in ways that break simple text matching. Use `browser_snapshot` ref IDs instead when possible.

## Overlap note

This skill covers storefront **management** (audit, fix, edit listings). The `gumroad-product-copy` skill covers copy **writing** (drafting listing descriptions, headlines, pricing strategy). The curator may consolidate these into a single `gumroad` umbrella.